<?php
/**
 * PHP-Nuke CE (Community Edition)
 * Admin bridge for Links.
 */

define('ADMIN_FILE', true);

$root = dirname(__DIR__, 2);
require_once $root . '/modules/admin_links/index.php';
