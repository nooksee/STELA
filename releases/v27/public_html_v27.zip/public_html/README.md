# nukeCE Attribution, Credits, and Manifesto Re-export

This archive contains the documentation and module scaffolding
for attribution, credits, and the nukeCE design manifesto.

If you need the full CMS tree re-exported, reply and it will be rebuilt.