# Authors & Stewards

- Francisco Burzi — original PHP-Nuke author
- Nuke Evolution contributors
- RavenNuke contributors
- Kevin Thomas — nukeCE (2012)
- nukeCE contributors
