# AI Assist for Downloads

Downloads AI is **assistive**:
- drafts metadata from readme/install files
- runs a safety scan report (deterministic rules + optional AI explanation)
- checks external URLs for broken links

Nothing auto-publishes.

Enable:
Admin → AI → Features:
- downloads_metadata
- downloads_safety_scan
- downloads_link_check
