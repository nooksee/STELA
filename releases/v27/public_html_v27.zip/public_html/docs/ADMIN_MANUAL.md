# PHP-Nuke CE Admin Manual
