# Add-ons

Core nukeCE stays focused.

Optional features ship as add-ons in `/addons/modules/`:
- `memberships_addon.zip` (support tiers / entitlements)
- `arcade_addon.zip` (games + leaderboards)

Intended to be offered through the future Downloads module.
