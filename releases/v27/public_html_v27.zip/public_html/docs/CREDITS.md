# Credits — PHP-Nuke CE

This project is a community-descended continuation of the PHP-Nuke lineage.

## Lineage
- **PHP-Nuke** by **Francisco Burzi**
- Community distros and forks (including **Nuke Evolution** and **RavenNuke**)
- **nukeCE (2012)** work by Kevin Thomas
- **nukeCE (current)**: coherence-first, security-first continuation

## Attribution
Upstream notices and license texts are preserved under `docs/upstream/`.

If code is removed, attribution moves with it (see `docs/REMOVAL_LEDGER.md`).
