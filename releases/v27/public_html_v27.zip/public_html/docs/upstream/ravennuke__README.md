RavenNuke™ is the smart choice to fulfill your needs; whether you need to build a simple or complex website, whether it is for your personal, organizational or business needs. It comes complete with a variety of great looking themes and a variety of built in modules that we are sure you will find extremely useful. If that is not enough, RavenNuke™ is search engine friendly,  conforms to security and web standards and has an active support community. There is also a large community dedicated to developing third party modules and other add-ons you can install. In short, RavenNuke™ was created with security, ease of use and ease of installation in mind which makes it the CMS of choice for both newcomers and seasoned web developers.

Support: http://www.ravenphpscripts.com

<hr>

For full installation instructions, please visit our documentation on-line at:

http://rnwiki.ravennuke.com/wiki/RavenNuke2:Installation

If you are upgrading from a previous RavenNuke(tm) installation or wishing to 
migrate from a different PHP-Nuke distribution to RavenNuke(tm), there is some
guidance on how to do this here:

http://rnwiki.ravennuke.com/wiki/RavenNuke2:Upgrades_and_Migrations

For Release Notes, detailed Change Log and other key information for upgraders, 
please visit our documentation on line at:

http://rnwiki.ravennuke.com/wiki/RavenNuke2:Release_Notes