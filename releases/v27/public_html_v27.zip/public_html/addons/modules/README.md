# nukeCE Add-ons

Optional, first-party add-ons ship here.

## Install (manual)
1. Unzip the add-on
2. Copy `modules/*` into your site `modules/`
3. Copy `blocks/*` into your site `blocks/` (if present)
4. If the add-on contains `/games`, copy it to your site root.

Visit the add-on's Admin module once to auto-create its DB tables.
