<?php
/**
 * PHP-Nuke CE
 * Clubs (DaDaClub lineage)
 */
require_once __DIR__ . '/../../mainfile.php';

$mod = new \NukeCE\Modules\Clubs\ClubsModule();
$mod->run();
