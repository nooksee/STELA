ALTER TABLE `nuke_users_temp` ADD `requestor` varchar(25) NOT NULL default '' AFTER `time`;
